var twilio=require('twilio');
var accountSid = 'AC83196bd0cd6ab00ffe622daf7a54af66'; // Your Account SID from www.twilio.com/console
var authToken = '271e5ff911359dd3ef4747129a8d2343';   // Your Auth Token from www.twilio.com/console

var twilio = require('twilio');
var client = new twilio(accountSid, authToken);

client.messages.create({
    body: 'Cant touch this... its getting too hot',
//  body: 'watch your taillight',
//    to: '+13136551850',  // Text this number
    to: '+12602430834',
    from: '+16308844183' // From a valid Twilio number
})

.then(console.log("Sending a message"));
